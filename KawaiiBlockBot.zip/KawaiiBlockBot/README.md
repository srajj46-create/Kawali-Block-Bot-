# Kawaii Block Puzzle Bot (Android)

Screen padhta hai -> board + 3 pieces detect karta hai -> best move nikalta hai -> drag karke girata hai.

## Build
1. Android Studio > Open > `KawaiiBlockBot` folder (Gradle sync hone do)
2. Phone USB debugging ON > Run ▶ (Android 11+ chahiye)
3. Phone: Settings > Accessibility > Installed apps > **Kawaii Block Bot** > ON
4. Game kholo > upar **START** dabao

## Agar kuch galat ho
- START ko **long-press** karo -> debug PNG save hoti hai
  (`Android/data/com.kawaiibot/files/debug/`). Green = empty cell, red = filled cell,
  cyan = detected pieces. Wo image mujhe bhej do, main tune kar dunga.
- Piece drop nahi ho raha: bot khud alag offsets try karke seekh leta hai; ya app mein Drag speed badhao/ghatao.
- Game over / ad / menu ke buttons: app mein "Recovery tap points" mein x,y (screen ka ratio) daalo.

## Maine jo rules maane (screen recording se)
10x10 board, piece board par KAHIN BHI rakh sakte ho (screenshots mein floating pieces dikhe), poori row/column bharne par clear.
"Gravity mode" sirf tab ON karo agar piece neeche girne lage.

## GitHub se APK banana (Android Studio ke bina)
1. GitHub par new repository banao, saari files upload karo (`.github/workflows/build.yml` samet)
2. Repo > **Actions** tab > "Build APK" > **Run workflow** (push par apne aap bhi chalta hai)
3. 3-5 min baad run khulo > neeche **Artifacts** > `KawaiiBlockBot-APK` download karo
4. Zip extract karke `app-debug.apk` phone mein install karo
