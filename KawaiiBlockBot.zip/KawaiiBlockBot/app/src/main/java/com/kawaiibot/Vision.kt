package com.kawaiibot

import android.graphics.Bitmap
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

const val N = 10

/** Tray ka ek piece. cells = [row, col] (piece ke andar). */
class Piece(val slot: Int, val w: Int, val h: Int, val cells: List<IntArray>, val cx: Float, val cy: Float) {
    val masks: IntArray by lazy {
        val m = IntArray(h)
        for (c in cells) m[c[0]] = m[c[0]] or (1 shl c[1])
        m
    }
    val sig: String get() = "$slot:$w:$h:" + cells.joinToString(",") { "${it[0]}${it[1]}" }
}

class Geo(val left: Float, val top: Float, val cw: Float, val ch: Float) {
    val bottom: Float get() = top + ch * N
}

/** rows[r] ka bit c = 1 matlab (r, c) cell bhara hua hai. r=0 sabse upar. */
class Scene(val geo: Geo, val rows: IntArray, val pieces: List<Piece>, val windows: List<IntArray>) {
    fun signature(): String = rows.joinToString(",") + "|" + pieces.joinToString(";") { it.sig }
}

class Vision(private val trayScale: () -> Float) {

    private fun isBrown(c: Int): Boolean {
        val r = (c shr 16) and 255
        val g = (c shr 8) and 255
        val b = c and 255
        return abs(r - 154) <= 12 && abs(g - 112) <= 12 && abs(b - 54) <= 12
    }

    fun read(bmp: Bitmap): Scene? {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val geo = detectBoard(px, w, h) ?: return null

        // ---- board occupancy ----
        val rows = IntArray(N)
        for (r in 0 until N) for (c in 0 until N) {
            val x0 = (geo.left + c * geo.cw + geo.cw * 0.2f).toInt()
            val x1 = (geo.left + c * geo.cw + geo.cw * 0.8f).toInt()
            val y0 = (geo.top + r * geo.ch + geo.ch * 0.2f).toInt()
            val y1 = (geo.top + r * geo.ch + geo.ch * 0.8f).toInt()
            var tot = 0
            var non = 0
            var y = y0
            while (y < y1) {
                var x = x0
                while (x < x1) {
                    tot++
                    if (!isBrown(px[y * w + x])) non++
                    x += 2
                }
                y += 2
            }
            if (tot > 0 && non.toFloat() / tot > 0.2f) rows[r] = rows[r] or (1 shl c)
        }

        // ---- tray pieces ----
        val gx = min(w - 1, (geo.left + 3.7f * geo.cw).toInt())
        val gy = min(h - 1, (geo.bottom + 1.6f * geo.ch).toInt())
        val gc = px[gy * w + gx]
        val gr = (gc shr 16) and 255
        val gg = (gc shr 8) and 255
        val gb = gc and 255
        fun sprite(x: Int, y: Int): Boolean {
            val c = px[y * w + x]
            val d = max(abs(((c shr 16) and 255) - gr), max(abs(((c shr 8) and 255) - gg), abs((c and 255) - gb)))
            return d > 60
        }

        val boardW = geo.cw * N
        val half = geo.cw * 1.36f
        val y0 = min(h - 1, (geo.bottom + geo.ch * 0.6f).toInt())
        val y1 = min(h, (geo.bottom + geo.ch * 0.6f + geo.cw * 3.2f).toInt())
        val t = geo.cw * trayScale()
        val pieces = ArrayList<Piece>()
        val windows = ArrayList<IntArray>()
        for (s in 0 until 3) {
            val cxs = geo.left + boardW / 2f + (s - 1) * 0.337f * boardW
            val xa = max(0, (cxs - half).toInt())
            val xb = min(w, (cxs + half).toInt())
            windows.add(intArrayOf(xa, y0, xb, y1))
            var minX = Int.MAX_VALUE; var maxX = -1; var minY = Int.MAX_VALUE; var maxY = -1; var cnt = 0
            for (y in y0 until y1) for (x in xa until xb) {
                if (sprite(x, y)) {
                    cnt++
                    if (x < minX) minX = x
                    if (x > maxX) maxX = x
                    if (y < minY) minY = y
                    if (y > maxY) maxY = y
                }
            }
            if (cnt < 60) continue
            val bw = (maxX - minX + 1).toFloat()
            val bh = (maxY - minY + 1).toFloat()
            val pw = ((bw + 0.1f * t) / t).roundToInt().coerceIn(1, 6)
            val ph = ((bh + 0.1f * t) / t).roundToInt().coerceIn(1, 6)
            val sw = (bw - (pw - 1) * t).coerceIn(0.5f * t, t)
            val sh = (bh - (ph - 1) * t).coerceIn(0.5f * t, t)
            val ox = minX + sw / 2f
            val oy = minY + sh / 2f
            val cells = ArrayList<IntArray>()
            for (i in 0 until ph) for (j in 0 until pw) {
                val ccx = ox + j * t
                val ccy = oy + i * t
                val sx0 = max(0, (ccx - t * 0.25f).toInt())
                val sx1 = min(w, (ccx + t * 0.25f).toInt())
                val sy0 = max(0, (ccy - t * 0.25f).toInt())
                val sy1 = min(h, (ccy + t * 0.25f).toInt())
                var tot = 0
                var on = 0
                for (y in sy0 until sy1) for (x in sx0 until sx1) {
                    tot++
                    if (sprite(x, y)) on++
                }
                if (tot > 0 && on.toFloat() / tot > 0.25f) cells.add(intArrayOf(i, j))
            }
            if (cells.isEmpty()) continue
            pieces.add(Piece(s, pw, ph, cells, (minX + maxX) / 2f, (minY + maxY) / 2f))
        }
        return Scene(geo, rows, pieces, windows)
    }

    /** Board ko uske bhure (empty cell) colour se dhoondhta hai: 154,112,54. */
    private fun detectBoard(px: IntArray, w: Int, h: Int): Geo? {
        val need = (w * 0.5f / 2f).toInt()
        var top = -1
        var bot = -1
        for (y in 0 until h) {
            var cnt = 0
            var x = 0
            val base = y * w
            while (x < w) { if (isBrown(px[base + x])) cnt++; x += 2 }
            if (cnt >= need) { if (top < 0) top = y; bot = y }
        }
        if (top < 0 || bot - top < w * 0.4f) return null
        val needC = ((bot - top) * 0.5f / 2f).toInt()
        var left = -1
        var right = -1
        for (x in 0 until w) {
            var cnt = 0
            var y = top
            while (y <= bot) { if (isBrown(px[y * w + x])) cnt++; y += 2 }
            if (cnt >= needC) { if (left < 0) left = x; right = x }
        }
        if (left < 0) return null
        val bw = right - left + 1
        val bh = bot - top + 1
        if (bw < w * 0.5f || abs(bw - bh) > 0.12f * bw) return null
        return Geo(left.toFloat(), top.toFloat(), bw / N.toFloat(), bh / N.toFloat())
    }
}
