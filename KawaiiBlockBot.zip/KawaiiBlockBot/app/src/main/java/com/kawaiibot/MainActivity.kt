package com.kawaiibot

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var cfg: Cfg
    private lateinit var statusTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        cfg = Cfg(this)
        val pad = (16 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(pad, pad, pad, pad) }
        setContentView(ScrollView(this).apply { addView(root) })

        root.addView(TextView(this).apply {
            text = "Kawaii Block Puzzle Bot"; textSize = 24f; setTypeface(null, Typeface.BOLD)
        })
        statusTv = TextView(this).apply { textSize = 15f; setPadding(0, pad / 2, 0, pad / 2) }
        root.addView(statusTv)

        root.addView(Button(this).apply {
            text = "1) Accessibility service ON karo"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(TextView(this).apply {
            textSize = 14f
            setPadding(0, pad / 2, 0, pad)
            text = "Steps:\n" +
                "• Settings > Accessibility > Installed apps > Kawaii Block Bot > ON\n" +
                "• Kawaii Block Puzzle kholo, upar chhota START button dikhega\n" +
                "• START dabao - bot khud khelega. STOP se ruk jayega\n" +
                "• Kuch galat ho to START ko long-press karo: debug image save hoti hai (Android/data/com.kawaiibot/files/debug)"
        })

        root.addView(heading("Settings"))
        seek(root, "Drag speed (ms)", 200, 900, cfg.dragMs) { cfg.dragMs = it }
        seek(root, "Move ke baad wait (ms)", 500, 2500, cfg.settleMs) { cfg.settleMs = it }
        seek(root, "Scan delay (ms)", 100, 800, cfg.scanMs) { cfg.scanMs = it }

        root.addView(CheckBox(this).apply {
            text = "Gravity mode (default OFF - piece kahin bhi rakh sakte ho)"
            isChecked = cfg.gravity
            setOnCheckedChangeListener { _, v -> cfg.gravity = v }
        })
        root.addView(CheckBox(this).apply {
            text = "Auto-recover (menu / game over par Play tap kare)"
            isChecked = cfg.autoRecover
            setOnCheckedChangeListener { _, v -> cfg.autoRecover = v }
        })
        root.addView(CheckBox(this).apply {
            text = "Bahut der atakne par Back button dabaye"
            isChecked = cfg.autoBack
            setOnCheckedChangeListener { _, v -> cfg.autoBack = v }
        })
        root.addView(TextView(this).apply { text = "Recovery tap points (screen ratio x,y ; x,y):"; setPadding(0, pad / 2, 0, 0) })
        root.addView(EditText(this).apply {
            setText(cfg.recoverPoints)
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { cfg.recoverPoints = s?.toString() ?: "" }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            })
        })
        root.addView(Button(this).apply {
            text = "Seekha hua drop-offset reset karo"
            setOnClickListener { cfg.offDx = 0f; cfg.offDy = 0f }
        })
    }

    override fun onResume() {
        super.onResume()
        val on = BotService.instance != null
        statusTv.text = if (on) "Service: ON \u2705 (ab game kholo)" else "Service: OFF \u274C (neeche button se ON karo)"
    }

    private fun heading(t: String): View = TextView(this).apply {
        text = t; textSize = 18f; setTypeface(null, Typeface.BOLD); setPadding(0, 8, 0, 8)
    }

    private fun seek(root: LinearLayout, label: String, lo: Int, hi: Int, cur: Int, onSet: (Int) -> Unit) {
        val t = TextView(this).apply { text = "$label: $cur" }
        val s = SeekBar(this).apply { this.max = hi - lo; progress = cur - lo }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, p: Int, u: Boolean) { val v = p + lo; t.text = "$label: $v"; onSet(v) }
            override fun onStartTrackingTouch(sb: SeekBar?) {}
            override fun onStopTrackingTouch(sb: SeekBar?) {}
        })
        root.addView(t); root.addView(s)
    }
}
