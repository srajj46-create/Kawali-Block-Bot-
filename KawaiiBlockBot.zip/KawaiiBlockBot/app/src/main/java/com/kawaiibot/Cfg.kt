package com.kawaiibot

import android.content.Context

/** Saari settings yahan save hoti hain (SharedPreferences). */
class Cfg(ctx: Context) {
    private val p = ctx.getSharedPreferences("kawaii_bot", Context.MODE_PRIVATE)

    var dragMs: Int
        get() = p.getInt("dragMs", 450)
        set(v) { p.edit().putInt("dragMs", v).apply() }
    var settleMs: Int
        get() = p.getInt("settleMs", 1100)
        set(v) { p.edit().putInt("settleMs", v).apply() }
    var scanMs: Int
        get() = p.getInt("scanMs", 250)
        set(v) { p.edit().putInt("scanMs", v).apply() }
    var gravity: Boolean
        get() = p.getBoolean("gravity", false)
        set(v) { p.edit().putBoolean("gravity", v).apply() }
    var autoRecover: Boolean
        get() = p.getBoolean("autoRecover", true)
        set(v) { p.edit().putBoolean("autoRecover", v).apply() }
    var autoBack: Boolean
        get() = p.getBoolean("autoBack", false)
        set(v) { p.edit().putBoolean("autoBack", v).apply() }
    var recoverPoints: String
        get() = p.getString("recoverPoints", "0.5,0.55") ?: ""
        set(v) { p.edit().putString("recoverPoints", v).apply() }
    var trayScale: Float
        get() = p.getFloat("trayScale", 0.52f)
        set(v) { p.edit().putFloat("trayScale", v).apply() }
    /** Bot khud seekhta hai: drop offset (cells mein). */
    var offDx: Float
        get() = p.getFloat("offDx", 0f)
        set(v) { p.edit().putFloat("offDx", v).apply() }
    var offDy: Float
        get() = p.getFloat("offDy", 0f)
        set(v) { p.edit().putFloat("offDy", v).apply() }

    fun recoverList(): List<Pair<Float, Float>> =
        recoverPoints.split(";").mapNotNull {
            val a = it.trim().split(",")
            val x = a.getOrNull(0)?.trim()?.toFloatOrNull()
            val y = a.getOrNull(1)?.trim()?.toFloatOrNull()
            if (x != null && y != null) Pair(x, y) else null
        }
}
