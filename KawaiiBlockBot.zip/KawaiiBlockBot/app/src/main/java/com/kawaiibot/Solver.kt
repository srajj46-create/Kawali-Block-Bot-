package com.kawaiibot

import kotlin.math.abs
import kotlin.math.max

class Move(val pieceIdx: Int, val c0: Int, val r0: Int, val score: Double, val clears: Int)

/**
 * Game model (screen recording se):
 *  - 10x10 board, piece ek column par seedha neeche girta hai (hard drop)
 *  - poora bhara column ya row clear ho jaata hai (column clear = bada bonus)
 * Search: tray ke saare pieces ke saare orders + saari positions par beam search.
 */
object Solver {
    private const val FULL = (1 shl N) - 1

    fun landing(b: IntArray, p: Piece, c0: Int): Int {
        val h = p.h
        val sh = IntArray(h) { p.masks[it] shl c0 }
        for (dr in 0 until h) if ((b[dr] and sh[dr]) != 0) return -1
        var r0 = 0
        while (r0 + 1 + h <= N) {
            var ok = true
            for (dr in 0 until h) if ((b[r0 + 1 + dr] and sh[dr]) != 0) { ok = false; break }
            if (!ok) break
            r0++
        }
        return r0
    }

    private fun fits(b: IntArray, p: Piece, c0: Int, r0: Int): Boolean {
        for (dr in 0 until p.h) if ((b[r0 + dr] and (p.masks[dr] shl c0)) != 0) return false
        return true
    }

    private fun placements(b: IntArray, p: Piece, gravity: Boolean): List<IntArray> {
        val out = ArrayList<IntArray>()
        for (c0 in 0..(N - p.w)) {
            if (gravity) {
                val r0 = landing(b, p, c0)
                if (r0 >= 0) out.add(intArrayOf(c0, r0))
            } else {
                for (r0 in 0..(N - p.h)) if (fits(b, p, c0, r0)) out.add(intArrayOf(c0, r0))
            }
        }
        return out
    }

    /** b ko badal deta hai; kitni lines (rows+columns) clear hui wo return karta hai. */
    private fun place(b: IntArray, p: Piece, c0: Int, r0: Int): Int {
        for (dr in 0 until p.h) b[r0 + dr] = b[r0 + dr] or (p.masks[dr] shl c0)
        var colAnd = FULL
        for (r in 0 until N) colAnd = colAnd and b[r]
        var cleared = Integer.bitCount(colAnd)
        for (r in 0 until N) {
            if (b[r] == FULL) { cleared++; b[r] = 0 } else b[r] = b[r] and colAnd.inv() and FULL
        }
        return cleared
    }

    private fun eval(b: IntArray): Double {
        var aggr = 0
        var bump = 0
        var holes = 0
        var maxH = 0
        var prev = -1
        for (c in 0 until N) {
            var top = -1
            for (r in 0 until N) if (((b[r] shr c) and 1) == 1) { top = r; break }
            val hg = if (top < 0) 0 else N - top
            if (top >= 0) for (r in top + 1 until N) if (((b[r] shr c) and 1) == 0) holes++
            aggr += hg
            maxH = max(maxH, hg)
            if (prev >= 0) bump += abs(hg - prev)
            prev = hg
        }
        val danger = if (maxH > 6) (maxH - 6) * (maxH - 6) else 0
        return -0.9 * aggr - 1.6 * bump - 7.0 * holes - 9.0 * danger
    }


    /** Free placement (piece kahin bhi): line fill badhao, ched/akele khaali cells aur bikhra board ghatao. */
    private fun evalFree(b: IntArray): Double {
        fun filled(r: Int, c: Int) = r < 0 || r >= N || c < 0 || c >= N || ((b[r] shr c) and 1) == 1
        var score = 0.0
        var cells = 0
        for (r in 0 until N) { val f = Integer.bitCount(b[r]); cells += f; score += f * f * 0.35 }
        for (c in 0 until N) {
            var f = 0
            for (r in 0 until N) f += (b[r] shr c) and 1
            score += f * f * 0.35
        }
        score -= cells * 1.0
        for (r in 0 until N) for (c in 0 until N) {
            if (filled(r, c)) continue
            var n = 0
            if (filled(r - 1, c)) n++
            if (filled(r + 1, c)) n++
            if (filled(r, c - 1)) n++
            if (filled(r, c + 1)) n++
            if (n == 4) score -= 12.0 else if (n == 3) score -= 4.0
        }
        var trans = 0
        for (r in 0 until N) {
            var prev = 1
            for (c in 0 until N) { val v = (b[r] shr c) and 1; if (v != prev) trans++; prev = v }
            if (prev == 0) trans++
        }
        for (c in 0 until N) {
            var prev = 1
            for (r in 0 until N) { val v = (b[r] shr c) and 1; if (v != prev) trans++; prev = v }
            if (prev == 0) trans++
        }
        score -= trans * 0.8
        var big = false
        for (r0 in 0..N - 3) for (c0 in 0..N - 3) {
            if (((b[r0] or b[r0 + 1] or b[r0 + 2]) and (7 shl c0)) == 0) big = true
        }
        if (!big) score -= 25.0
        val free = N * N - cells
        if (free < 25) score -= (25 - free) * 2.0
        return score
    }

    private class St(val rows: IntArray, val used: Int, val clears: Int, val first: Move?, val score: Double)

    /** Best se worst tak first-move ki list. */
    fun rank(rows: IntArray, pieces: List<Piece>, gravity: Boolean): List<Move> {
        val beam = if (gravity) 400 else 80
        var level: List<St> = listOf(St(rows, 0, 0, null, 0.0))
        var last: List<St> = emptyList()
        for (depth in pieces.indices) {
            val next = ArrayList<St>()
            for (s in level) for (pi in pieces.indices) {
                if (((s.used shr pi) and 1) == 1) continue
                for (pl in placements(s.rows, pieces[pi], gravity)) {
                    val nb = s.rows.clone()
                    val cl = place(nb, pieces[pi], pl[0], pl[1])
                    val first = s.first ?: Move(pi, pl[0], pl[1], 0.0, cl)
                    val clears = s.clears + cl
                    next.add(St(nb, s.used or (1 shl pi), clears, first, clears * 120.0 + (if (gravity) eval(nb) else evalFree(nb))))
                }
            }
            if (next.isEmpty()) break
            next.sortByDescending { it.score }
            level = if (next.size > beam) next.subList(0, beam).toList() else next
            last = level
        }
        val best = HashMap<String, Move>()
        for (s in last) {
            val f = s.first ?: continue
            val key = "${f.pieceIdx}:${f.c0}:${f.r0}"
            val old = best[key]
            if (old == null || old.score < s.score) best[key] = Move(f.pieceIdx, f.c0, f.r0, s.score, f.clears)
        }
        return best.values.sortedByDescending { it.score }
    }
}
