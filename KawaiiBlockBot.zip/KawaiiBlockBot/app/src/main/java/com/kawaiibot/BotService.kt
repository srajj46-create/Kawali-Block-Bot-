package com.kawaiibot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Accessibility service: screenshot leta hai, board padhta hai, solver se best move nikalta hai,
 * aur drag gesture se piece ko board par girata hai. Upar chhota Start/Stop overlay dikhta hai.
 */
class BotService : AccessibilityService() {

    companion object {
        @Volatile var instance: BotService? = null
    }

    private lateinit var cfg: Cfg
    private lateinit var vision: Vision
    private val main = Handler(Looper.getMainLooper())
    private val shotExec = Executors.newSingleThreadExecutor()
    private var worker: Thread? = null
    @Volatile private var alive = true
    @Volatile private var running = false
    @Volatile private var lastBmp: Bitmap? = null
    @Volatile private var lastScene: Scene? = null
    private var wm: WindowManager? = null
    private var box: View? = null
    private var btn: Button? = null
    private var statusTv: TextView? = null
    private var moves = 0
    private var clears = 0
    private var screenW = 1080
    private var screenH = 2400

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        cfg = Cfg(this)
        vision = Vision { cfg.trayScale }
        buildOverlay()
        alive = true
        worker = Thread({ loop() }, "kawaii-bot").also { it.isDaemon = true; it.start() }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        alive = false
        running = false
        try { box?.let { wm?.removeView(it) } } catch (_: Throwable) {}
        instance = null
        return super.onUnbind(intent)
    }

    // ------------------------------------------------------------------ overlay
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildOverlay() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(0xDD202020.toInt())
            setPadding(dp(6), dp(4), dp(6), dp(4))
            gravity = Gravity.CENTER_VERTICAL
        }
        val b = Button(this).apply { text = "START"; textSize = 12f; minWidth = 0; minimumWidth = 0 }
        val tv = TextView(this).apply {
            text = "Ready (drag karke hata sakte ho)"
            textSize = 11f
            setTextColor(Color.WHITE)
            setPadding(dp(8), 0, dp(4), 0)
        }
        row.addView(b)
        row.addView(tv)
        btn = b
        statusTv = tv
        box = row
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(24)
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    w.updateViewLayout(row, lp)
                }
            }
            true
        }
        b.setOnClickListener { toggle() }
        b.setOnLongClickListener { dump(); true }
        w.addView(row, lp)
    }

    private fun toggle() {
        running = !running
        if (running) { moves = 0; clears = 0 }
        main.post { btn?.text = if (running) "STOP" else "START" }
        status(if (running) "Chalu..." else "Ruka hua (long-press START = debug image)")
    }

    private fun status(t: String) { main.post { statusTv?.text = t } }
    private fun toast(t: String) { main.post { Toast.makeText(this, t, Toast.LENGTH_LONG).show() } }
    private fun nap(ms: Long) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }

    // ------------------------------------------------------------------ capture & gestures
    private fun capture(): Bitmap? {
        val latch = CountDownLatch(1)
        var out: Bitmap? = null
        takeScreenshot(Display.DEFAULT_DISPLAY, shotExec, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(result: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = result.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, result.colorSpace)
                    out = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hw?.recycle()
                    hb.close()
                } catch (_: Throwable) {}
                latch.countDown()
            }
            override fun onFailure(errorCode: Int) { latch.countDown() }
        })
        latch.await(2, TimeUnit.SECONDS)
        return out
    }

    private fun gesture(path: Path, ms: Long): Boolean {
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms)).build()
        val latch = CountDownLatch(1)
        var ok = false
        val cb = object : AccessibilityService.GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { ok = true; latch.countDown() }
            override fun onCancelled(d: GestureDescription?) { latch.countDown() }
        }
        main.post { if (!dispatchGesture(g, cb, null)) latch.countDown() }
        latch.await(ms + 1500, TimeUnit.MILLISECONDS)
        return ok
    }

    private fun drag(x0: Float, y0: Float, x1: Float, y1: Float): Boolean {
        val p = Path().apply { moveTo(x0, y0); lineTo(x1, y1) }
        return gesture(p, cfg.dragMs.toLong())
    }

    private fun tap(x: Float, y: Float) {
        gesture(Path().apply { moveTo(x, y) }, 80)
    }

    private fun ourAppOnTop(): Boolean = try {
        rootInActiveWindow?.packageName?.toString() == packageName
    } catch (_: Throwable) { false }

    // ------------------------------------------------------------------ main loop
    private fun variations(): List<Pair<Float, Float>> = listOf(
        Pair(cfg.offDx, cfg.offDy), Pair(0f, -1.5f), Pair(0f, -3f), Pair(0f, 1.5f),
        Pair(0.4f, 0f), Pair(-0.4f, 0f), Pair(0f, -5f)
    )

    private fun recover(n: Int) {
        if (!cfg.autoRecover || n < 3) return
        val pts = cfg.recoverList()
        if (pts.isNotEmpty()) {
            val (fx, fy) = pts[(n - 3) % pts.size]
            tap(fx * screenW, fy * screenH)
        }
        if (cfg.autoBack && n % 30 == 0) performGlobalAction(GLOBAL_ACTION_BACK)
    }

    private fun loop() {
        var prevSig: String? = null
        var stable = 0
        var lastMoveSig: String? = null
        var lastVar = 0
        var fail = 0
        var stuck = 0
        while (alive) {
            if (!running) { prevSig = null; stable = 0; nap(200); continue }
            if (ourAppOnTop()) { status("Game kholo, phir bot chalega"); nap(600); continue }
            val bmp = capture()
            if (bmp == null) { nap(400); continue }
            screenW = bmp.width
            screenH = bmp.height
            val scene = try { vision.read(bmp) } catch (_: Throwable) { null }
            lastBmp = bmp
            lastScene = scene
            if (scene == null) {
                stuck++
                status("Board nahi mila ($stuck) - menu/ad/animation?")
                recover(stuck)
                prevSig = null; stable = 0
                nap(900); continue
            }
            if (scene.pieces.isEmpty()) {
                status("Pieces ka wait...")
                prevSig = null; stable = 0
                nap(300); continue
            }
            val sig = scene.signature()
            if (sig == prevSig) stable++ else { stable = 1; prevSig = sig }
            if (stable < 2) { nap(cfg.scanMs.toLong()); continue }

            // pichhli move ka result check
            val lm = lastMoveSig
            if (lm != null) {
                if (sig == lm) {
                    fail++
                } else {
                    if (fail > 0 && lastVar > 0) {
                        val v = variations()[lastVar]
                        cfg.offDx = v.first; cfg.offDy = v.second   // offset seekh liya
                    }
                    fail = 0
                }
                lastMoveSig = null
            }

            val ranked = Solver.rank(scene.rows, scene.pieces, cfg.gravity)
            if (ranked.isEmpty()) {
                stuck++
                status("Koi valid move nahi ($stuck) - game over?")
                recover(stuck)
                nap(900); continue
            }
            stuck = 0
            val vars = variations()
            val mv = ranked[(fail / vars.size).coerceAtMost(ranked.size - 1)]
            lastVar = fail % vars.size
            val (vdx, vdy) = vars[lastVar]
            val pc = scene.pieces[mv.pieceIdx]
            val g = scene.geo
            val tx = (g.left + (mv.c0 + pc.w / 2f + vdx) * g.cw).coerceIn(5f, screenW - 5f)
            val ty = (g.top + (mv.r0 + pc.h / 2f + vdy) * g.ch).coerceIn(5f, screenH - 5f)

            lastMoveSig = sig
            drag(pc.cx, pc.cy, tx, ty)
            moves++
            clears += mv.clears
            status("Moves $moves | clears ~$clears" + if (fail > 0) " | retry $fail" else "")
            prevSig = null; stable = 0
            nap(cfg.settleMs.toLong())
        }
    }

    // ------------------------------------------------------------------ debug image
    private fun dump() {
        val b = lastBmp
        if (b == null) { toast("Abhi koi screenshot nahi hai - pehle START karo"); return }
        val s = lastScene
        val c = b.copy(Bitmap.Config.ARGB_8888, true)
        val cv = Canvas(c)
        val p = Paint().apply { style = Paint.Style.STROKE; strokeWidth = 3f }
        if (s != null) {
            val g = s.geo
            p.color = Color.GREEN
            for (r in 0 until N) for (cc in 0 until N) {
                val occ = ((s.rows[r] shr cc) and 1) == 1
                p.color = if (occ) Color.RED else Color.GREEN
                cv.drawRect(g.left + cc * g.cw, g.top + r * g.ch, g.left + (cc + 1) * g.cw, g.top + (r + 1) * g.ch, p)
            }
            p.color = Color.YELLOW
            for (wnd in s.windows) cv.drawRect(wnd[0].toFloat(), wnd[1].toFloat(), wnd[2].toFloat(), wnd[3].toFloat(), p)
            p.color = Color.CYAN
            val t = g.cw * cfg.trayScale
            for (pc in s.pieces) {
                cv.drawRect(pc.cx - pc.w * t / 2, pc.cy - pc.h * t / 2, pc.cx + pc.w * t / 2, pc.cy + pc.h * t / 2, p)
            }
        }
        val dir = getExternalFilesDir("debug") ?: filesDir
        val f = File(dir, "debug_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { c.compress(Bitmap.CompressFormat.PNG, 90, it) }
        toast("Debug image saved: ${f.absolutePath}")
    }
}
